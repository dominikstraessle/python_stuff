from setuptools import setup

setup(
    name='oracle_database_connection',
    version='1.0',
    description='A Context Manager Protocol for Oracle Database access.',
    author='Dominik Strässle',
    py_modules=['connection'],
)
